CODEVAULT PROGRAMMING LIBRARY

- Extract this ZIP and open index.html in a modern browser.
- Add, edit, search, filter, favorite, copy, delete and organize code snippets.
- Export backup downloads a JSON backup. Import backup restores/merges snippets.
- To publish on GitHub Pages: upload index.html to the repository root, then Settings > Pages > Deploy from a branch > main > /(root) > Save.

IMPORTANT: snippets are stored locally in this browser on this device. They are not synced online. Export backups regularly. This website stores code as text and does not compile/run it.
